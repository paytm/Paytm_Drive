<?php
namespace One97\Paytm\Cron;
use Magento\Sales\Model\Order;
use One97\Paytm\Model\Paytm;
use Psr\Log\LoggerInterface;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Framework\DB\TransactionFactory;

class WebhookCron
{
    protected $logger;
    protected $paytmModel;
    protected $orderModel;
    private $invoiceService;
    private $transactionFactory;

    protected const STATUS_PROCESSING   = 'success';
    protected const STATUS_PENDING      = 'pending';
    protected const STATUS_CANCELED     = 'failure';    
   
    public function __construct( 
       LoggerInterface $logger,
       Paytm $paytmModel,
       Order $orderModel,
       InvoiceService $invoiceService,
       TransactionFactory $transactionFactory,
      
    ){
      
        $this->logger = $logger;
        $this->paytmModel = $paytmModel;
        $this->orderModel = $orderModel;
        $this->invoiceService = $invoiceService;
        $this->transactionFactory = $transactionFactory;
       
    }

    public function execute()
    {
        $this->logger->info('Paytm webhook Cron starts');
       
        //webhook code

                $currentTime = $this->paytmModel->getDate();
                $endTime = date('Y-m-d H:i:s', strtotime("-1 minutes", strtotime($currentTime))); 
				$startTime = date('Y-m-d H:i:s', strtotime("-360 minutes", strtotime($currentTime))); 

                $order_status=static::STATUS_PENDING;
                $connection = $this->paytmModel->dbConnection(); 
				$paytmWebhookTable = $this->paytmModel->paytmWebhookTable();   

                $sql = "SELECT * FROM ".$paytmWebhookTable." WHERE order_status='".$order_status."' AND webhook_response IS NOT NULL AND webhook_timestamp BETWEEN '".$startTime."' AND '".$endTime."' ";
                $this->logger->info($sql);
                $result = $connection->fetchAll($sql);   

				foreach($result as $val){
					$paytmOrderId = $val["paytm_order_id"];
					$magentoOrderIdArr=explode('_', $paytmOrderId ?? '');
	        		$magentoOrderId=$magentoOrderIdArr[0];
                      $this->logger->info($magentoOrderId); 
                    $order = $this->orderModel->loadByIncrementId($magentoOrderId);  
					$webhook_response = json_decode($val["webhook_response"],true); 
                    $orderStatus = $order->getStatus();
                    $this->logger->info($orderStatus); 
                          
					if($webhook_response["STATUS"] == "TXN_SUCCESS"){   
                        $newStatus = $this->paytmModel->getSuccessOrderStatus();
                        $order->setState(\Magento\Sales\Model\Order::STATE_PROCESSING);
                        $order->setStatus($newStatus);
                        $order->setExtOrderId($paytmOrderId);
                        $order->addStatusToHistory($newStatus, 'Order status updated to Success via Paytm Webhook');
                        $order->save(); 
                        $autoInvoice =  $this->paytmModel->autoInvoiceGen();
		        		if($autoInvoice=='authorize_capture'){ 
                            $invoice = $this->invoiceService->prepareInvoice($order);
                            $invoice->register();
                            $invoice->setState(\Magento\Sales\Model\Order\Invoice::STATE_PAID);
                            $invoice->save(); 
                            $transaction = $this->transactionFactory->create();
                            $transaction->addObject($invoice)
                                ->addObject($invoice->getOrder())
                                ->save(); 
		        		}
						$order_Status =static::STATUS_PROCESSING;
						$this->paytmModel->updateOrderStatusWebhook($order_Status, $paytmOrderId);
                        
					}elseif($webhook_response["STATUS"] == "TXN_FAILURE"){  
                        $newStatus = $this->paytmModel->getFailOrderStatus();
                        $order->setState(\Magento\Sales\Model\Order::STATE_CANCELED);
                        $order->setStatus($newStatus);
                        $order->addStatusToHistory($newStatus, 'Order status updated to failure via Paytm Webhook');
                        $order->save(); 
						$order_Status =static::STATUS_CANCELED;
						$this->paytmModel->updateOrderStatusWebhook($order_Status, $paytmOrderId);
					}
                    
				}
        // webhook code end

        $this->logger->info('Paytm webhook Cron end');


    }

   
}