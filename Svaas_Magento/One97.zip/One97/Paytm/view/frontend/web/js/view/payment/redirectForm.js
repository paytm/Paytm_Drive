require(['jquery'],function($){
    $(document).ready(function(){
       $('#paytmFormPost').submit();

    });
});
