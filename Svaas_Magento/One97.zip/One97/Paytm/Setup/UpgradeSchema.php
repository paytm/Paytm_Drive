<?php

namespace One97\Paytm\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\DB\Ddl\Table;

class UpgradeSchema implements UpgradeSchemaInterface
{
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        if (!$installer->tableExists('paytm_order_data')) {
            $this->paytmTransactionsData($installer);
        }
        if (!$installer->tableExists('paytm_webhook_data')) {
            $this->paytmWebhookData($installer);
        }
        $installer->endSetup();
    }
    private function paytmTransactionsData(SchemaSetupInterface $installer)
    { 
        $connection = $installer->getConnection();
        $table = $connection
            ->newTable($installer->getTable('paytm_order_data'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity'=>true,'unsigned'=>true,'nullable'=>false,'primary'=>true],
                'ID'
            )
            ->addColumn(
                'order_id',
                Table::TYPE_TEXT,
                null,
                ['nullable'=>false,'default'=>''],
                'Magento OrderId'
            )
            ->addColumn(
                'paytm_order_id',
                Table::TYPE_TEXT,
                null,
                ['nullable'=>false,'default'=>''],
                'Paytm OrderId'
            )
            ->addColumn(
                'transaction_id',
                Table::TYPE_TEXT,
                null,
                ['nullable'=>false,'default'=>''],
                'Paytm TransactionId'
            )
            ->addColumn(
                'status',
                Table::TYPE_BOOLEAN,
                null,
                ['nullable'=>false,'default'=>'0'],
                'Transaction Status'
            )
            ->addColumn(
                'paytm_response',
                Table::TYPE_TEXT,
                null,
                ['nullable'=>false,'default'=>''],
                'Paytm Response'
            )
            ->addColumn(
                'date_added',
                Table::TYPE_DATETIME,
                null,
                ['nullable'=>false,'default'=>'0000-00-00 00:00:00'],
                'Created Date'
            )
            ->addColumn(
                'date_modified',
                Table::TYPE_DATETIME,
                null,
                ['nullable'=>false,'default'=>'0000-00-00 00:00:00'],
                'Modified Date'
            )
            ->setOption('charset','utf8'); 
        $connection->createTable($table);
    }
 
    private function paytmWebhookData(SchemaSetupInterface $installer)
    {
        $connection = $installer->getConnection();
        $table = $connection
            ->newTable($installer->getTable('paytm_webhook_data'))
            ->addColumn(
                        'id',
                        Table::TYPE_INTEGER,
                        null,
                        ['identity'=>true,'unsigned'=>true,'nullable'=>false,'primary'=>true],
                        'ID'
                    )
                    ->addColumn(
                        'order_id',
                        Table::TYPE_TEXT,
                        null,
                        ['nullable'=>false,'default'=>''],
                        'Magento OrderId'
                    )
                    ->addColumn(
                        'paytm_order_id',
                        Table::TYPE_TEXT,
                        null,
                        ['nullable'=>false,'default'=>''],
                        'Paytm OrderId'
                    ) 
                    ->addColumn(
                        'order_status',
                        Table::TYPE_TEXT,
                        null,
                        ['nullable'=>true,'default'=> null],
                        'Order Status'
                    )
                    ->addColumn(
                        'webhook_response',
                        Table::TYPE_TEXT,
                        null,
                        ['nullable'=>true,'default'=> null],
                        'Webhook Response'
                    )
                    ->addColumn(
                        'webhook_timestamp',
                        Table::TYPE_DATETIME,
                        null,
                        ['nullable'=>true,'default'=> null],
                        'Created Date'
                    ) 
                    ->setOption('charset','utf8'); 
                    $connection->createTable($table);
    }

      
}