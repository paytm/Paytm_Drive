//
//  PaytmNativeSDK.h
//  PaytmNativeSDK
//
//  Created by Sumit Garg on 07/01/20.
//  Copyright © 2020 Sumit Garg. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PaytmNativeSDK.
FOUNDATION_EXPORT double PaytmNativeSDKVersionNumber;

//! Project version string for PaytmNativeSDK.
FOUNDATION_EXPORT const unsigned char PaytmNativeSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaytmNativeSDK/PublicHeader.h>


