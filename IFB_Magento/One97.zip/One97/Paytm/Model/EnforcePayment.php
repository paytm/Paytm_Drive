<?php
    namespace One97\Paytm\Model;

    class EnforcePayment implements \Magento\Framework\Option\ArrayInterface {
        public function toOptionArray() {
            return [['value']];
        }
 
    }
?>