<?php
	namespace One97\Paytm\Controller\Standard;
	use Magento\Framework\App\CsrfAwareActionInterface;
	use Magento\Framework\App\Request\InvalidRequestException;
	use Magento\Framework\App\RequestInterface;

	class Response extends \One97\Paytm\Controller\Paytm  implements CsrfAwareActionInterface{

		public function createCsrfValidationException(
		    RequestInterface $request
		): ?InvalidRequestException {
		    return null;
		}

		public function validateForCsrf(RequestInterface $request): ?bool {
		    return true;
		}
		/* this funtion handle Paytm response */
	    public function execute() { 
	    	$comment = "";
	    	$request = $_POST;
			if(!empty($_POST)){
				foreach($_POST as $key => $val){
					if($key != "CHECKSUMHASH"){
						$comment .= $key  . "=" . $val . ", \n <br />";
					}
				}
			}
			
			$errorMsg = '';
			$successFlag = false;
			$resMessage=$this->getRequest()->getParam('RESPMSG');
			$globalErrMass="Your payment has been failed!";
			if(trim((string) $resMessage)!=''){
				$globalErrMass.=" Reason: ".$resMessage;
			}
			$returnUrl = $this->getPaytmHelper()->getUrl('/');
		    $orderMID = $this->getRequest()->getParam('MID');        
	        $paytmOrderId = $this->getRequest()->getParam('ORDERID');
	        $magentoOrderIdArr=explode('_', $paytmOrderId ?? '');
	        $magentoOrderId=$magentoOrderIdArr[0];
	        $orderTXNID = $this->getRequest()->getParam('TXNID');
	        $paytmResponse=$this->getRequest()->getParams();
	        $paytmJsonResponse=json_encode($paytmResponse);
	        
	        if(trim((string) $paytmOrderId)!='' && trim((string) $orderMID)!=''){
		        $order = $this->getOrderById($magentoOrderId);
		        $orderTotal = round((float) $order->getGrandTotal(), 2);
				$orderStatus = $this->getRequest()->getParam('STATUS'); 
				$resCode = $this->getRequest()->getParam('RESPCODE');
		        $orderTxnAmount = $this->getRequest()->getParam('TXNAMOUNT');
				$transactionResponse="";
				$paytmJsonResponseOnPending='';
			  	$success_order_status = $this->getPaytmModel()->getSuccessOrderStatus(); 
			  	$failure_order_status = $this->getPaytmModel()->getFailOrderStatus(); 
			 
			if($success_order_status != $order->getStatus() && $failure_order_status != $order->getStatus()){
			    if($this->getPaytmModel()->validateResponse($request, $magentoOrderId)) { 
			        if($this->getPaytmHelper()::SAVE_PAYTM_RESPONSE){
				        $date = $this->getPaytmModel()->getDate(); 
				        $tableName = $this->getPaytmModel()->paytmTable();
				        $this->updateTable(
				            $tableName,
				            [
				                'transaction_id' => (string) $orderTXNID,
				                'paytm_response' => (string) $paytmJsonResponse,
				                'date_modified' => $date
				            ],
				            [
				                'order_id = ?' => (string) $magentoOrderId,
				                'paytm_order_id = ?' => (string) $paytmOrderId
				            ]
				        );
				    } 
					if($orderStatus == "TXN_SUCCESS"){ 
						$requestParamList = array("MID" => $orderMID , "ORDERID" => $paytmOrderId);
						$responseParamList=$this->checkStatusCall($requestParamList);  
						if(isset($responseParamList['STATUS'])){
							if($responseParamList['STATUS'] == "PENDING"){
								$transactionResponse="PENDING";
							}else{
								if($responseParamList['STATUS']=='TXN_SUCCESS' && $responseParamList['TXNAMOUNT']==$orderTxnAmount) {
									$transactionResponse="PROCESSING";
								} else{
									$transactionResponse="CANCELED";
								}
							}
						}else{
							$transactionResponse="FRAUD";
						}
					}else{
						if($orderStatus == "PENDING"){
							$requestParamList = array("MID" => $orderMID , "ORDERID" => $paytmOrderId);
							$responseParamList=$this->checkStatusCall($requestParamList);
							if(isset($responseParamList['STATUS'])){
								if($responseParamList['STATUS'] == "PENDING"){
									$transactionResponse="PENDING";
								}else{
									if($responseParamList['STATUS']=='TXN_SUCCESS' && $responseParamList['TXNAMOUNT']==$orderTxnAmount) {
										$transactionResponse="PROCESSING";
										$paytmJsonResponseOnPending=json_encode($responseParamList);
									} else{
										$transactionResponse="CANCELED";
									}
								}
							}else{
								$transactionResponse="FRAUD";
							}
						}else{
							$transactionResponse="CANCELED";
						}
					}            
		        } else { 
					$transactionResponse="FRAUD_CHECKSUM_MISMATCH";
		        } 
		        switch ($transactionResponse) {
		        	case 'FRAUD':
		        		$errorMsg = 'It seems some issue in server to server communication. Kindly connect with administrator.';
		        		$comment .=  "Fraud Detected";
		        		$order->setStatus($order::STATUS_FRAUD);
		        		$returnUrl = $this->getPaytmHelper()->getUrl('checkout/cart');
		        		break;
		        	case "FRAUD_CHECKSUM_MISMATCH":
    					$errorMsg = $globalErrMass." Reason: Checksum Mismatch.";
    					$comment .=  "Fraud Detected";
    		            $order->setState("canceled")->setStatus($order::STATUS_FRAUD);
    					$returnUrl = $this->getPaytmHelper()->getUrl('checkout/cart');
		        		break;
		        	case "CANCELED":
		        		if($orderStatus == "PENDING"){
		        			$errorMsg = 'Paytm Transaction Pending!';
		        			if(trim((string) $resMessage)==''){
		        				$errorMsg.=" Reason: ".$resMessage;
		        			}
		        			$comment .=  "Pending";
		        			$order->setState("pending_payment")->setStatus("pending_payment");
		        		}else{ 
							$order->cancel()->save();
		        			$errorMsg = $globalErrMass;
		        			$comment .=  $globalErrMass;
		        			$order->setState("canceled")->setStatus($this->_paytmModel->getFailOrderStatus());
		        		}
		        		$returnUrl = $this->getPaytmHelper()->getUrl('checkout/cart');
		        		break;
		        	case "PROCESSING":
		        		$tableName = $this->getPaytmModel()->paytmTable();
		        		$bind = $paytmJsonResponseOnPending === ''
		        		    ? ['status' => 1]
		        		    : ['status' => 1, 'paytm_response' => (string) $paytmJsonResponseOnPending];
		        		if($this->getPaytmHelper()::SAVE_PAYTM_RESPONSE){
		        			$this->updateTable(
		        			    $tableName,
		        			    $bind,
		        			    [
		        			        'order_id = ?' => (string) $magentoOrderId,
		        			        'paytm_order_id = ?' => (string) $paytmOrderId
		        			    ]
		        			);
		        		}
	        			$autoInvoice =  $this->getPaytmModel()->autoInvoiceGen();
		        		if($autoInvoice=='authorize_capture'){
		        			$payment = $order->getPayment();
		        			$payment->setTransactionId($orderTXNID)       
		        			->setPreparedMessage(__('Paytm transaction has been successful.'))
		        			->setShouldCloseParentTransaction(true)
		        			->setIsTransactionClosed(0)
		        			->setAdditionalInformation(['One97','paytm'])		
		        			->registerCaptureNotification(
		        				$responseParamList['TXNAMOUNT'],
		        				true 
		        			);
		        			$invoice = $payment->getCreatedInvoice();
		        		}
		        		$successFlag = true;
		        		$comment .=  "Success ";
		        		$order->setState('processing');
		        		$order->setStatus($this->_paytmModel->getSuccessOrderStatus());
		        		$order->setExtOrderId($paytmOrderId);
		        		$this->clearCart();  
		        		$returnUrl = $this->getPaytmHelper()->getUrl('checkout/onepage/success');
		        		break;
		        	case "PENDING":
		        		$errorMsg = 'Paytm Transaction Pending!';
		        		if(trim((string) $resMessage)==''){
		        			$errorMsg.=" Reason: ".$resMessage;
		        		}
		        		$comment .=  "Pending";
		        		$order->setState("pending_payment")->setStatus("pending_payment");
		        		$this->clearCart();
		        		$returnUrl = $this->getPaytmHelper()->getUrl('checkout/onepage/failure');
		        		break;

		        	default:
		        		$errorMsg = 'Paytm Transaction Pending!';
		        		if(trim((string) $resMessage)==''){
		        			$errorMsg.=" Reason: ".$resMessage;
		        		}
		        		$comment .=  "Pending" ;
		        		$order->setState("pending_payment")->setStatus("pending_payment");
		        		$returnUrl = $this->getPaytmHelper()->getUrl('checkout/cart');
		        		break;
		        }
				$order->addStatusToHistory($order->getStatus(), $comment);
		        $order->save();
				if ($successFlag) {
					$this->sendOrderConfirmationEmail($order);
				} elseif ($order->getStatus() == $success_order_status && !$order->getEmailSent()) {
					$this->sendOrderConfirmationEmail($order);
				}
				if($successFlag){
					$this->messageManager->addSuccess( __('Paytm transaction has been successful.') );
				}else{
					$this->messageManager->addError( __($errorMsg) );
				}
				if(isset($_GET['webhook']) && $_GET['webhook'] == "yes"){ 
					exit;
				}else{
					$this->getResponse()->setRedirect($returnUrl);
				}
				
	        }else{ 
				if(isset($_GET['webhook']) && $_GET['webhook'] == "yes"){ 
					exit;
				}  
				if($success_order_status == $order->getStatus()){
					 
					$returnUrl = $this->getPaytmHelper()->getUrl('checkout/onepage/success');
					 
				}elseif($failure_order_status == $order->getStatus()){
					 
					$returnUrl = $this->getPaytmHelper()->getUrl('checkout/onepage/failure');
					 
				}else{
					$returnUrl = $this->getPaytmHelper()->getUrl('checkout/cart');
				 
				}
				$this->getResponse()->setRedirect($returnUrl);
			  
		 }  
		}
	}

		/* Paytm transaction status S2S call */
		public function checkStatusCall($requestParamList){
			$response=array();
			if(!empty($requestParamList)){
				$StatusCheckSum  =  $this->getPaytmModel()->generateStatusChecksum($requestParamList);
				$requestParamList['CHECKSUMHASH'] = $StatusCheckSum;
				$check_status_url = $this->getPaytmModel()->getNewStatusQueryUrl(); 
				$responseParamList=array();
				$retry = $this->getPaytmHelper()::MAX_RETRY_COUNT;
				do{
					$response = $this->getPaytmHelper()->executecUrl($check_status_url, $requestParamList);
					$retry++;
				} while(empty($response) && $retry < $retry);
			}
			return $response;
		}

		public function updateTable($tableName, array $bind, array $where){
			$updateDone=false;
			if($tableName !== '' && $bind !== [] && $where !== []){
				$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
				$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
				$connection = $resource->getConnection();
				$connection->update($tableName, $bind, $where);
				$updateDone=true;
			}
			return $updateDone;
		}

	public function getClearCartUrl(){
        $checkoutSession = $this->getCheckoutSession();
        $quoteId = $checkoutSession->getQuote()->getId();
        $quoteItem = $this->getQuoteModel()->load($quoteId);
        $quoteItem->delete();
        $checkoutSession->getQuote()->setIsActive(false)->save();
    }

    public function getCheckoutSession(){
        $checkoutSession = $this->_objectManager->get('Magento\Checkout\Model\Session');//checkout session
        return $checkoutSession;
    }

    public function getQuoteModel(){
        $quoteModel = $this->_objectManager->create('Magento\Quote\Model\Quote');//Quote item model to load quote
        return $quoteModel;
    }
	function clearCart(){
			 $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 
             $cartObject = $objectManager->create('Magento\Checkout\Model\Cart')->truncate(); 
             $checkoutSession = $this->_objectManager->get('Magento\Checkout\Model\Session');
             $checkoutSession->getQuote()->setIsActive(false)->save();
             $quoteId = $checkoutSession->getQuote()->getId();
             $quoteItem = $this->getQuoteModel()->load($quoteId);
             $quoteItem->delete();

	}
	}
?>