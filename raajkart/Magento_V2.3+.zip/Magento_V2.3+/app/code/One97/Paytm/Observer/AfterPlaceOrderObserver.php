<?php
    namespace One97\Paytm\Observer;

    use Magento\Framework\Event\Observer;
    use Magento\Framework\Event\ObserverInterface;
    use Magento\Sales\Model\Order\Payment;
    use One97\Paytm\Model\Paytm;

    class AfterPlaceOrderObserver implements ObserverInterface
    {
        protected $checkoutSession;

        public function __construct(
            \Magento\Checkout\Model\Session $checkoutSession
        ) {
            $this->checkoutSession = $checkoutSession;
        }

        public function execute(Observer $observer)
        {
            /** @var Payment $payment */
            $payment = $observer->getData('payment');

            if ($payment === null) {
                return;
            }

            $payMethod = $payment->getMethodInstance();

            if ($payMethod->getCode() === Paytm::CODE) {
                $this->checkoutSession->setForceOrderMailSentOnSuccess(false);
            }
        }
    }
?>
