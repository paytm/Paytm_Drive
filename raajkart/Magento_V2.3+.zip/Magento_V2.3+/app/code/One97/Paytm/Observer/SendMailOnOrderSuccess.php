<?php
    namespace One97\Paytm\Observer;

    use Magento\Framework\Event\ObserverInterface;
    use One97\Paytm\Model\Paytm;

    class SendMailOnOrderSuccess implements ObserverInterface
    {
        protected $orderModel;
        protected $orderSender;
        protected $checkoutSession;

        public function __construct(
            \Magento\Sales\Model\OrderFactory $orderModel,
            \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender,
            \Magento\Checkout\Model\Session $checkoutSession
        ) {
            $this->orderModel = $orderModel;
            $this->orderSender = $orderSender;
            $this->checkoutSession = $checkoutSession;
        }

        public function execute(\Magento\Framework\Event\Observer $observer)
        {
            $orderIds = $observer->getEvent()->getOrderIds();
            if (!count($orderIds)) {
                return;
            }

            $order = $this->orderModel->create()->load($orderIds[0]);

            if ($order->getPayment() === null
                || $order->getPayment()->getMethod() !== Paytm::CODE
            ) {
                return;
            }

            try {
                $this->checkoutSession->setForceOrderMailSentOnSuccess(true);
                $this->orderSender->send($order, true);
            } finally {
                $this->checkoutSession->unsForceOrderMailSentOnSuccess();
            }
        }
    }
?>
